package br.com.gustavo.cadastro_de_pessoa;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CadastroDePessoaApplicationTests {

	@Test
	void contextLoads() {
	}

}
