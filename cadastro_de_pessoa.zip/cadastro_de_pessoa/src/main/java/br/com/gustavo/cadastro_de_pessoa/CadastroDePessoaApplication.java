package br.com.gustavo.cadastro_de_pessoa;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CadastroDePessoaApplication {

	public static void main(String[] args) {
		SpringApplication.run(CadastroDePessoaApplication.class, args);
	}

}
